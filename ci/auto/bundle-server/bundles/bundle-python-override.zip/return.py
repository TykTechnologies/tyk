from tyk.decorators import *
from gateway import TykGateway as tyk

@Hook
def MyRequestHook(request, session, metadata, spec):
    request.object.return_overrides.headers['X-Foo'] = 'Bar'
    request.object.return_overrides.response_code = 501
    request.object.return_overrides.response_body = "custom error"
    request.object.return_overrides.override_error = True

    return request, session, metadata