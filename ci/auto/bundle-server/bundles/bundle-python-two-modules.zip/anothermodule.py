def testfunction():
    print("testfunction is called")
    pass